package version

var Version = "v1.0.0"
