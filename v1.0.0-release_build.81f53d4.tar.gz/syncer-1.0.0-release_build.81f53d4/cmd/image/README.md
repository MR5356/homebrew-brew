# registry image syncer
A docker registry tool, synchronize images from source registry to target registry.

